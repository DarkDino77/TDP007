Bilmärke 	poäng
BMW 	5
Citroen 	4
Fiat 	3
Ford 	4
Mercedes 	5
Nissan 	4
Opel 	4
Volvo 	5


Postnummer 	poäng
# p för postnummer
p58937       9
p58726 	     5
p58647 	     3


Körkort antal år 	poäng
# k för körkort
k "0-1 år	3"
k "2-3 år 	4"
k "4-15 år 	4,5"
k "16-99 år 	5"


Kön 	poäng
Kvinna 	1
Man 	1

Ålder 	poäng
# a för age (man hade kunnat ha å för ålder men det är lite kinkigare än a)
a "18-20 år 	2,5"
a "21-23 år 	3"
a "24-26 år 	3,5"
a "27-29 år 	4"
a "30-39 år 	4,5"
a "40-64 år 	5"
a "65-70 år 	4"
a "71-99 år 	3"